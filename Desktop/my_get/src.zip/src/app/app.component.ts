import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { UserService } from './core/services/user.service';
import { UserModel } from './core/models/user.model';
import { } from  '@types/googlemaps';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public users: Array<UserModel> = [];
  @ViewChild('gmap') gmapElement: any;

  map: google.maps.Map;
  

  constructor(private userService: UserService) {

  }
  ngOnInit(): void {
    this.userService.getUsers()
      .subscribe((data) => {
        this.users = data;
      }, (err) => {
        console.log(err);

      }, () => { });
      

        let mapProp = {
          center: new google.maps.LatLng(18.5793, 73.8143),
          zoom: 15,
          mapTypeId: google.maps.MapTypeId.ROADMAP 
        };
        this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);

      
  }
  
 
}
